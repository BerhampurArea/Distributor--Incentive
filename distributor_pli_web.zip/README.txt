
Distributor PLI - November 2025 calculator (static site)
Files:
- index.html : single page app using React (CDN). Drop into any static host (GitHub Pages).
Usage: open index.html in a browser.

Notes:
- This is a client-side estimator matching the Distributor scheme document.
- For production, host on GitHub Pages or your web server.
